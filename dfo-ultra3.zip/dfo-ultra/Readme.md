# ULTRA

## Сборка окружения

```
docker compose build
```

## Запуск

```
docker compose up -d
```
