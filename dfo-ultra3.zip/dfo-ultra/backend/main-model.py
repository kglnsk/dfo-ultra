from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse,JSONResponse
from diffusers import AutoPipelineForText2Image
from fastapi.middleware.cors import CORSMiddleware
import torch
from io import BytesIO
from PIL import Image
from pydantic import BaseModel

# Initialize the text-to-image pipeline
pipe = AutoPipelineForText2Image.from_pretrained("kandinsky-community/kandinsky-3", variant="fp16", torch_dtype=torch.float16)
pipe.enable_model_cpu_offload()
generator = torch.Generator(device="cuda").manual_seed(42)

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Replace '*' with the actual frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pydantic model for the request body
class TextRequest(BaseModel):
    text: str

# FastAPI endpoint

# Function to generate an image from text
def generate_image(text: str):
    images = pipe(f"""{text}, иллюстрация, красивое изображение, 4к, Generate draw in the absence of text style""", num_inference_steps=50)
    return images[0][0]

@app.get("/")
async def root():
    return JSONResponse(content={"message": "FastAPI server is running."})


# FastAPI endpoint
@app.post("/generate_image/")
async def generate_image_endpoint(request: TextRequest):
    try:
        image = generate_image(request.text)
        # Convert PIL image to bytes
        img_byte_arr = BytesIO()
        image.save(img_byte_arr, format='PNG')
        img_byte_arr.seek(0)
        return StreamingResponse(img_byte_arr, media_type="image/png")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
