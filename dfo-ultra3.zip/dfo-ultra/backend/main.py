# main.py
from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel,Field
import openai
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
import json
from typing import Dict, List
import random
from minio import Minio
import os
from datetime import timedelta
import requests 
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor
from colorthief import ColorThief
from PIL import Image, ImageDraw, ImageFont
import qrcode
import io
from minio.error import S3Error

minio_client = Minio(
      endpoint="localhost:9000",
      access_key='6hCKaZnRbWBlm3IDf5p3',
      secret_key='T6AB3do6ln61HXqBCXR6SPpmmACN78WhRWDQy1HM',
      secure=False,
    )

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Replace '*' with the actual frontend URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class Formats(BaseModel):
    InfoBoards: bool
    DemoSystems: bool
    LockScreens: bool
    IntranetPortal: bool
    NewsDigest: bool
    TVPanel: bool
    InfoMessage: bool

class SlideRequest(BaseModel):
    text: str
    formats: Formats

class ImageResponse(BaseModel):
    url: str
    type: str

class SlideResponse(BaseModel):
    images: List[ImageResponse]
    presentation: str

def generate_image(text, output_file):
    url = "https://b796-148-77-2-74.ngrok-free.app/generate_image/"
    headers = {"Content-Type":"application/json"}
    data = {"text": text}

    response = requests.post(url, json=data, headers=headers)

    if response.status_code == 200:
        with open(output_file, 'wb') as file:
            file.write(response.content)
        print(f"Image saved to {output_file}")
    else:
        print(f"Failed to generate image. Status code: {response.status_code}, Response: {response.text}")

# Usage

def bucket_upload(file_path):
    bucket_name = "test-bucket"
    object_name = file_path.split('/')[-1]
    print(os.listdir())
    print(object_name,flush=True)
    try:
        # Check if the bucket exists
        found = minio_client.bucket_exists(bucket_name)
        print("FOUND = ",found,flush = True)
        if not found:
            minio_client.make_bucket(bucket_name)
            print(f"Bucket '{bucket_name}' created successfully.",flush=True)
        else:
            print(f"Bucket '{bucket_name}' already exists.",flush=True)

        # Upload the file
        result = minio_client.fput_object(
            bucket_name,
            object_name,
            file_path,
        )
        print(f"File uploaded successfully. ETag: {result.etag}",flush=True)
    except S3Error as err:
        print(f"Error occurred: {err}")
    return 0 

@app.post("/api/generate_slide")
async def generate_slide(request: SlideRequest):
    # Process the request here
    merged_data = llm_parse(str(request.text))
    generate_image(str(merged_data['illustration']), f"./output1.png")
    _ = bucket_upload('./output1.png')

    create_presentation(
    image_path='output.png',
    title=merged_data['title'],
    subtitle=merged_data['subtitle'],
    button_text='Подробнее',
    qr_link=None)
    _ = bucket_upload('./output.pptx')

    
    images = []
    for format_type, is_enabled in request.formats.dict().items():
        if is_enabled:
            images.append(ImageResponse(url="http://localhost:9000/test-bucket/output.png", type=format_type))
    
    response = SlideResponse(
        images=images,
        presentation="http://localhost:9000/test-bucket/output.pptx"
    )
    return response

client = openai.OpenAI(
    api_key = 'fba55128c5cf945c1c3e8349d5e86b2d284015f2faf0eab3c0cd46ab4dfef179',
    base_url = "https://api.together.xyz/v1",
)


# Define the schema for the output.
class Presentation(BaseModel):
    title: str = Field(description = 'Заголовок текста тезиса (главное предложение/словосочетание)')
    subtitle: str = Field(description="Подзаголовок текста тезиса (остальная часть тезиса")
    illustration: str = Field(description="Очень КРАТКОЕ (три-четыре слова) описание иллюстрации к тезису")


def llm_parse(text):
    promptstring = f"""
ТЕКСТ ТЕЗИСА:
    {text}
    """
    
    # Generate
    chat_completion = client.chat.completions.create(
    model="mistralai/Mixtral-8x7B-Instruct-v0.1",
    response_format={
        "type": "json_object", 
        "schema": Presentation.model_json_schema()
    },
    messages=[
        {"role": "system", "content": "Ты - помощник иллюстратора и составителя презентаций. Извлеки из текста основной заголовок (главное словосочетание), подзаголовок (оставшаяся часть предложения), и придумай очень краткое описание иллюстрации, которая хорошо привлечет внимание к этой новости. При описании иллюстрации будь конкретен, утверждай, а не предлагай (избегай слов можно, должна, итд)."},
        {"role": "user", "content": promptstring}
    ])

    merged_data = json.loads(chat_completion.choices[0].message.content)
    print(json.dumps(merged_data, indent=2))
    return merged_data
    

def create_presentation(image_path, title, subtitle, button_text, qr_link=None):
    # Load the image and extract the dominant color
    color_thief = ColorThief(image_path)
    dominant_color = color_thief.get_color(quality=1)

    # Create a presentation object
    prs = Presentation()

    # Define slide layout
    slide_layout = prs.slide_layouts[5]  # Use a blank slide layout
    slide = prs.slides.add_slide(slide_layout)

    # Set the background color of the slide
    background = slide.background
    fill = background.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(*dominant_color)

    # Add the image to the slide
    left = Inches(5)
    top = Inches(2)
    pic = slide.shapes.add_picture(image_path, left, top, height=Inches(4))

    # Add title
    title_box = slide.shapes.add_textbox(Inches(1), Inches(1.5), Inches(8), Inches(1))
    title_frame = title_box.text_frame
    title_frame.text = title
    title_frame.paragraphs[0].font.size = Pt(32)
    title_frame.paragraphs[0].font.name = 'Arial'
    title_frame.paragraphs[0].font.bold = True
    title_frame.paragraphs[0].alignment = PP_ALIGN.LEFT

    # Add subtitle
    subtitle_box = slide.shapes.add_textbox(Inches(1), Inches(2.5), Inches(8), Inches(1))
    subtitle_frame = subtitle_box.text_frame
    subtitle_frame.text = subtitle
    subtitle_frame.paragraphs[0].font.size = Pt(20)
    subtitle_frame.paragraphs[0].font.name = 'Arial'
    subtitle_frame.paragraphs[0].alignment = PP_ALIGN.LEFT

    # Add button or QR code
    if qr_link:
        # Generate QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(qr_link)
        qr.make(fit=True)
        img = qr.make_image(fill='black', back_color='white')

        # Save QR code to a byte stream
        byte_stream = io.BytesIO()
        img.save(byte_stream, format='PNG')
        byte_stream.seek(0)

        # Add QR code to slide
        left = Inches(1)
        top = Inches(4)
        slide.shapes.add_picture(byte_stream, left, top, height=Inches(1.5))
    else:
        # Add "Подробнее" button
        button_box = slide.shapes.add_textbox(Inches(1), Inches(4), Inches(3), Inches(1))
        button_frame = button_box.text_frame
        button_frame.text = button_text
        button_frame.paragraphs[0].font.size = Pt(20)
        button_frame.paragraphs[0].font.name = 'Arial'
        button_frame.paragraphs[0].alignment = PP_ALIGN.CENTER

        # Set button background color and make it rounded
        button_box.fill.solid()
        button_box.fill.fore_color.rgb = RGBColor(255, 87, 87)  # red color
        button_box.line.color.rgb = RGBColor(255, 87, 87)

    # Save the presentation
    prs.save('output.pptx')


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8085)

