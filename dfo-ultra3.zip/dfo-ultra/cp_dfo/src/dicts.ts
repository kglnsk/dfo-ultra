export const TYPES_DICT: Record<string, string> = {
  InfoBoards: 'Информационная доска',
  DemoSystems: 'Тейбл тент',
  LockScreens: 'Экран блокировки',
  IntranetPortal: 'Интернет-портал',
  NewsDigest: 'Дайджест новостей',
  TVPanel: 'ТВ-панель',
  InfoMessage: 'Инф. сообщение'
}
